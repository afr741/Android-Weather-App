package com.ImprovedClima.androidweatherapp.json;


public class Clouds {

    private String all;

    public Clouds(String all) {
        this.all = all;
    }

    public String getAll() {
        return all;
    }
}
